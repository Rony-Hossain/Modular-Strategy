"""
Activities for the autonomous ML pipeline.

Stage 1 fixes:
- generic list_files(dir, extensions) replaces the bugged list_artifacts-for-scripts
- hardcoded D:/Ninjatrader-Modular-Startegy/ removed; repo_root flows via context
- script review budget raised from 8k to 20k chars
- accumulated_insights kept sharp via head-and-tail summarization
- audit_phase_confidence activity added (confidence gate before Phase 17)
- build_ml_proposal activity added (structured MLProposal output)
- claude_plan_ml_phase handles inline_prompt for micro-phases
- claude_evaluate_ml_output now returns confidence_level + optional micro-phase
"""

import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional

from temporalio import activity

from app.config import Settings
from app.roles import get_runner
from app.pipeline_logger import PipelineLogger
from app.script_validator import validate_script, ValidationResult
from app.insights_filter import filter_insights
from app.ml_models import (
    ConfidenceAudit,
    ConfidenceLevel,
    GeminiScriptRequest,
    MLPhaseContext,
    MLProposal,
    PhaseEvaluation,
    PhaseResult,
    ScriptReviewDecision,
    ScriptRunResult,
)


def _gemini(role: str):
    """DEPRECATED — preserved for legacy callers. Use get_runner() instead."""
    return get_runner("script_writer")


# ---------------------------------------------------------------------------
# File system activities (generalized — fixes the list_artifacts bug)
# ---------------------------------------------------------------------------

@activity.defn
async def list_files(directory: str, extensions: Optional[List[str]] = None) -> List[str]:
    """Generic file lister. If extensions is None, returns all files."""
    d = Path(directory)
    if not d.exists():
        return []
    if extensions:
        ext_set = {e if e.startswith(".") else f".{e}" for e in extensions}
        return sorted(f.name for f in d.iterdir() if f.is_file() and f.suffix in ext_set)
    return sorted(f.name for f in d.iterdir() if f.is_file())


@activity.defn
async def list_artifacts(artifacts_dir: str) -> List[str]:
    """Backward-compatible: parquet, csv, md, json artifacts."""
    d = Path(artifacts_dir)
    if not d.exists():
        return []
    exts = {".parquet", ".csv", ".md", ".json"}
    return sorted(f.name for f in d.iterdir() if f.is_file() and f.suffix in exts)


@activity.defn
async def list_scripts(scripts_dir: str) -> List[str]:
    """Lists .py scripts — what the old list_artifacts call in the workflow
    was trying (and failing) to do."""
    d = Path(scripts_dir)
    if not d.exists():
        return []
    return sorted(f.name for f in d.iterdir() if f.is_file() and f.suffix == ".py")


@activity.defn
async def read_plan_document(plan_path: str) -> str:
    p = Path(plan_path)
    return p.read_text(encoding="utf-8") if p.exists() else ""


@activity.defn
async def read_schema(schema_path: str) -> str:
    p = Path(schema_path)
    if not p.exists():
        return ""
    return "\n".join(p.read_text(encoding="utf-8").splitlines()[:200])


@activity.defn
async def read_strategy_config_snippet(config_path: str) -> str:
    p = Path(config_path)
    if not p.exists():
        return ""
    return "\n".join(p.read_text(encoding="utf-8").splitlines()[:120])


# ---------------------------------------------------------------------------
# Intelligence: artifact content sampling (so Claude sees real data shapes)
# ---------------------------------------------------------------------------

@activity.defn
async def sample_artifact_contents(
    artifacts_dir: str,
    artifact_names: List[str],
    max_per_file: int = 20,
) -> Dict[str, str]:
    """
    Read the first N rows of each artifact so Claude knows exact column names,
    dtypes, and data shapes — not just file names.

    Returns {filename: preview_string}.
    """
    log = PipelineLogger.get()
    d = Path(artifacts_dir)
    previews: Dict[str, str] = {}

    for name in artifact_names[:10]:  # cap at 10 files
        p = d / name
        if not p.exists():
            continue

        try:
            if p.suffix == ".parquet":
                import pyarrow.parquet as pq
                table = pq.read_table(str(p))
                schema_str = str(table.schema)
                n_rows = table.num_rows
                # Show schema + first few rows as string
                df = table.slice(0, min(max_per_file, n_rows)).to_pandas()
                previews[name] = (
                    f"Schema: {schema_str}\n"
                    f"Rows: {n_rows}\n"
                    f"Head:\n{df.to_string(max_rows=max_per_file, max_cols=15)}"
                )
            elif p.suffix == ".csv":
                lines = p.read_text(encoding="utf-8").splitlines()
                previews[name] = (
                    f"Rows: {len(lines) - 1}\n"
                    f"Head:\n" + "\n".join(lines[:max_per_file + 1])
                )
            elif p.suffix in (".md", ".json"):
                text = p.read_text(encoding="utf-8")
                previews[name] = text[:2000]
        except Exception as e:
            previews[name] = f"ERROR reading: {e}"
            log.warning("artifacts", f"Failed to sample {name}: {e}")

    log.event("ARTIFACT_SAMPLE", count=len(previews),
              files=list(previews.keys()))
    return previews


# ---------------------------------------------------------------------------
# Intelligence: sample dependent scripts (so Gemini sees output shapes)
# ---------------------------------------------------------------------------

@activity.defn
async def sample_dependent_scripts(
    scripts_dir: str,
    dependency_script_names: List[str],
    max_lines: int = 40,
) -> Dict[str, str]:
    """
    Read the tail of each dependency script (the part that writes outputs)
    so Gemini knows exact column names and output paths.
    """
    d = Path(scripts_dir)
    snippets: Dict[str, str] = {}

    for name in dependency_script_names[:5]:
        p = d / name
        if not p.exists():
            continue
        lines = p.read_text(encoding="utf-8").splitlines()
        # The output logic is usually in the last N lines
        if len(lines) <= max_lines * 2:
            snippets[name] = "\n".join(lines)
        else:
            # Head (imports + constants) + tail (save logic)
            head = lines[:15]
            tail = lines[-max_lines:]
            snippets[name] = (
                "\n".join(head) +
                f"\n\n# ... ({len(lines) - 15 - max_lines} lines omitted) ...\n\n" +
                "\n".join(tail)
            )

    return snippets


# ---------------------------------------------------------------------------
# Helper: summarize accumulated insights (keep it sharp, not truncated-dumb)
# ---------------------------------------------------------------------------

def _summarize_insights(insights: str, max_chars: int = 4000) -> str:
    """
    Keep accumulated insights useful even after many phases. Strategy:
    - Always keep lines marked [ANOMALY] or FOLLOW-UP (high-signal)
    - Fill remaining budget with most-recent lines
    - Never silently truncate — note what was dropped
    """
    if not insights or len(insights) <= max_chars:
        return insights or ""

    lines = insights.splitlines()
    high_signal = [ln for ln in lines if "ANOMALY" in ln or "FOLLOW-UP" in ln]
    other = [ln for ln in lines if ln not in high_signal]

    kept = list(high_signal)
    budget_remaining = max_chars - sum(len(ln) + 1 for ln in kept)

    # Fill from the tail (most recent) of the "other" list
    for ln in reversed(other):
        if budget_remaining - len(ln) - 1 < 0:
            break
        kept.append(ln)
        budget_remaining -= len(ln) + 1

    dropped = len(lines) - len(kept)
    header = f"# Accumulated insights ({len(kept)} kept, {dropped} older dropped — anomalies always retained)\n"
    return header + "\n".join(kept)


# ---------------------------------------------------------------------------
# CLAUDE — Plan a phase
# ---------------------------------------------------------------------------

@activity.defn
async def claude_plan_ml_phase(context: MLPhaseContext) -> GeminiScriptRequest:
    """
    Two-stage planning:
      Stage 1: Gemini drafter reads context, produces a structured draft plan.
      Stage 2: Claude editor critiques the draft and emits the FINAL prompt
               that Gemini's script writer will receive.

    Why this design (vs. all-Claude planning):
      - Drafter does the heavy reading (plan doc, schema, config, insights):
        ~12kb input on Gemini at $0.005, vs. same input on Claude at $0.05.
      - Editor only sees: original mission + draft + targeted critique
        prompt — ~5kb to Claude, ~70% reduction on the most expensive call.
      - Editor's job is supervision: catch hallucinated tags, missing inputs,
        violations of the spec. The drafter's job is breadth.

    Micro-phase short-circuit: when the workflow inserts a Claude-driven
    micro-phase, we skip the drafter entirely (Claude already designed
    the micro-phase) and go straight to building the writer prompt.
    """
    log = PipelineLogger.get()
    log.step("PLAN", context.phase_id,
             f"planning {context.script_name}"
             + (" (RETRY)" if context.retry_error else "")
             + (" (MICRO)" if context.is_micro_phase else ""),
             prompt_snippet=context.plan_prompt[:200])

    # Filter accumulated insights to what's actually relevant for THIS phase.
    # Cuts token cost AND removes noise that confuses the planner.
    relevant_insights = ""
    if context.accumulated_insights:
        # MLPhaseContext doesn't carry dependencies directly; recover from
        # accumulated_insights structure if needed. For now, no dep filter
        # at this layer — the workflow will pass dependencies in via context
        # in a future revision.
        relevant_insights = filter_insights(
            accumulated_insights=context.accumulated_insights.splitlines()
                if isinstance(context.accumulated_insights, str)
                else (context.accumulated_insights or []),
            current_phase_id=context.phase_id,
            phase_dependencies=[],   # workflow doesn't pass these yet; safe default
            phase_spec_text=context.plan_prompt,
            max_chars=3000,
        )

    # ----- Build the cacheable prefix (stable across all phases) -----
    cacheable_prefix = _build_cacheable_planning_prefix(context)

    # ----- Stage 1: Gemini draft (skipped for micro-phases) -----
    if context.is_micro_phase:
        # Claude already specified this; just enrich for the script writer
        draft = _build_micro_phase_draft(context)
    else:
        draft = await _gemini_draft_plan(context, relevant_insights)

    # ----- Stage 2: Claude edits the draft into the final writer prompt -----
    result = await _claude_edit_plan(
        context=context,
        draft=draft,
        relevant_insights=relevant_insights,
        cacheable_prefix=cacheable_prefix,
    )

    log.step_done("PLAN", context.phase_id,
                  f"Final writer prompt ready ({len(result.prompt)} chars)",
                  response_snippet=result.prompt[:300])
    return result


def _build_cacheable_planning_prefix(context: MLPhaseContext) -> str:
    """
    Static-across-phases content: schema, strategy config, role doc, repo root.
    Marked as cacheable so the API charges 10% on subsequent calls within 5min.
    """
    return f"""You are working on the autonomous ML pipeline for a NinjaTrader
backtest analysis. The pipeline is dual-LLM: Gemini drafts plans and writes
analysis scripts, Claude supervises with critique and review.

REPO ROOT: {context.repo_root}
ARTIFACTS DIR: {context.repo_root}/Analysis/artifacts
SCRIPTS DIR: {context.repo_root}/Analysis/scripts

DATA SCHEMA (stable across phases):
{context.schema_content[:5000]}

STRATEGY CONFIG (stable across phases):
{context.strategy_config_snippet[:2500]}

QUALITY REQUIREMENTS that apply to EVERY phase:
- Minimum sample size for findings: n ≥ {context.min_sample_size} (smaller
  samples must be flagged INSUFFICIENT, not reported as findings).
- Statistical rigor: confidence intervals, effect sizes, distribution checks
  before parametric methods, bootstrap for n<50.
- Defensive code: handle empty DataFrames, missing columns, division by zero.
- Reproducibility: np.random.seed(42) wherever randomness appears.
- Output: print() calls with [INPUT] [CHECK] [RESULT] [SAVED] sections;
  add [DISCOVERY] [ANOMALY] [INSIGHT] when warranted.

KNOWN PATHOLOGIES to watch for:
- Inverted score correlations (signal predicts opposite of intent).
- Empty cells producing NaN that propagate silently.
- Lookahead bias from joins that mix bar timestamps incorrectly.
- Per-source thresholds that disable everything (limit=99 = effectively off).
- Hallucinated tag types: schema lists 19 known tags; any tag your script
  references must be in that list.
"""


def _build_micro_phase_draft(context: MLPhaseContext) -> dict:
    """For micro-phases, Claude already wrote the plan inline."""
    return {
        "mission": "Claude-initiated micro-phase deep-dive.",
        "inline_request": context.plan_prompt,
        "input_files_specified": [],
        "output_artifacts_specified": [],
        "required_analysis": "(see inline_request above)",
    }


async def _gemini_draft_plan(
    context: MLPhaseContext,
    relevant_insights: str,
) -> dict:
    """
    Stage 1: ask Gemini to read everything and produce a structured draft.
    Uses Gemini's native structured output for reliability.
    """
    from pydantic import BaseModel
    from typing import List as _List

    class DraftPlan(BaseModel):
        mission: str                          # one paragraph
        input_files: _List[str]               # exact filenames from existing_artifacts
        output_artifacts: _List[str]          # filenames the script will write
        required_analyses: _List[str]         # numbered checks the script must do
        statistical_methods: _List[str]       # tests, CIs, bootstraps to use
        defensive_requirements: _List[str]    # edge cases to handle
        cross_phase_dependencies: _List[str]  # which prior findings shape this
        known_failure_modes: _List[str]       # how this could be technically right but wrong

    drafter = get_runner("plan_drafter")

    prompt = f"""Draft a structured plan for Phase {context.phase_id} ({context.script_name}).

You are the DRAFTER role. A senior reviewer (Claude) will critique your draft
before it goes to the script writer. Be specific, reference exact filenames
and column names from the schema, do NOT invent tags or columns that aren't
listed in the schema.

PHASE PLAN DOCUMENT:
{context.plan_prompt[:8000]}

EXISTING ARTIFACTS YOU CAN READ (use these EXACT filenames):
{', '.join(context.existing_artifacts) if context.existing_artifacts else '(none yet)'}

{('PRIOR PHASE INSIGHTS:' + chr(10) + relevant_insights) if relevant_insights else ''}

{f'PREVIOUS PHASE SUMMARY: {context.previous_phase_summary}' if context.previous_phase_summary else ''}

{f'CRITICAL — PRIOR ATTEMPT FAILED with: {context.retry_error[:1500]}' if context.retry_error else ''}

Walk these layers in your reasoning, then produce the JSON draft:
1. OBJECTIVE — what specific question does this phase answer?
2. GAP ANALYSIS — what does the plan doc miss? (distributions, regimes,
   cross-correlations, lookahead risk)
3. STATISTICAL RIGOR — what tests/CIs/bootstraps are required?
4. FAILURE MODES — how could this produce a technically-correct but wrong answer?
5. INPUT FILE SELECTION — list ONLY artifacts from the available list above.
   If the plan mentions a file not in the list, flag it in cross_phase_dependencies.

Be concise and concrete. Each list item should be one sentence."""

    return (await drafter.prompt_json(prompt, DraftPlan)).model_dump()


async def _claude_edit_plan(
    context: MLPhaseContext,
    draft: dict,
    relevant_insights: str,
    cacheable_prefix: str,
) -> GeminiScriptRequest:
    """
    Stage 2: Claude reviews Gemini's draft, catches errors, emits the final
    writer prompt. This is the supervision layer.
    """
    editor = get_runner("planner")

    # The draft + critique prompt is small (~5k vs. 15k for original)
    edit_prompt = f"""Review the draft plan below (produced by Gemini drafter)
and emit the FINAL prompt that will go to the script writer.

Phase: {context.phase_id} — {context.script_name}
Min sample size: n ≥ {context.min_sample_size}

PHASE PLAN DOC (the source of truth — defer to it):
{context.plan_prompt[:6000]}

GEMINI DRAFTER'S OUTPUT:
mission: {draft.get('mission', '(missing)')}
input_files: {draft.get('input_files', [])}
output_artifacts: {draft.get('output_artifacts', [])}
required_analyses:
{chr(10).join(f'  - {a}' for a in draft.get('required_analyses', []))}
statistical_methods:
{chr(10).join(f'  - {a}' for a in draft.get('statistical_methods', []))}
defensive_requirements:
{chr(10).join(f'  - {a}' for a in draft.get('defensive_requirements', []))}
known_failure_modes:
{chr(10).join(f'  - {a}' for a in draft.get('known_failure_modes', []))}

AVAILABLE ARTIFACTS (writer can ONLY read these):
{', '.join(context.existing_artifacts) if context.existing_artifacts else '(none)'}

{('RELEVANT PRIOR INSIGHTS:' + chr(10) + relevant_insights) if relevant_insights else ''}

YOUR JOB AS EDITOR — verify and correct:
1. Does the draft's input_files list ONLY files in the available artifacts?
   If it references files not in the list, REMOVE or REPLACE them.
2. Did the draft hallucinate tag types or column names? Check against schema.
3. Does the draft cover EVERY check in the phase plan doc, or did it skip some?
4. Did the draft miss the n≥{context.min_sample_size} requirement?
5. Are the statistical methods appropriate for the data sizes available?
6. Are there cross-phase coherence issues (contradicts a prior insight)?

Then emit the FINAL writer prompt with these sections in order:
- MISSION (one paragraph from the plan doc, refined)
- INPUT FILES (exact paths under {context.repo_root}/Analysis/artifacts/,
  ONLY referencing files in the available list above)
- OUTPUT ARTIFACTS (exact paths the script will write)
- REQUIRED ANALYSIS (numbered checks from the plan doc, with the corrections
  you made above; specify EVERY check the plan doc lists)
- STATISTICAL METHODS (concrete: which test, what CI level, bootstrap n)
- OUTPUT SECTIONS (script MUST call print('[INPUT] ...'), print('[CHECK] ...'),
  print('[RESULT] ...'), print('[SAVED] ...') — these are runtime print
  calls, NOT bare lines in the source code)
- DEFENSIVE REQUIREMENTS (specific edge cases for this phase)
- MINIMUM SAMPLE SIZE: enforce n ≥ {context.min_sample_size} via a constant
  MIN_N at the top; flag findings below as INSUFFICIENT
- CROSS-PHASE CONTEXT (only what's relevant — don't dump prior insights blindly)

Return JSON:
- prompt (the complete final writer prompt — self-contained for Gemini)
- phase_id ({context.phase_id})
- script_name ({context.script_name})"""

    return await editor.prompt_json(
        edit_prompt,
        GeminiScriptRequest,
        cached_prefix=cacheable_prefix,
    )


# ---------------------------------------------------------------------------
# Fast-path planning for skip_planning phases (templated bug-hunt audits)
# ---------------------------------------------------------------------------

@activity.defn
async def fast_plan_ml_phase(context: MLPhaseContext) -> GeminiScriptRequest:
    """
    No Claude in the loop. The plan doc is wrapped with minimum scaffolding
    and handed straight to the writer. Used for phases marked skip_planning
    in the registry — typically the bug-hunt audits that follow a
    deterministic template.

    The script_validator gate still runs after the writer, so we don't
    lose quality protection — we just lose the upfront plan critique
    where it isn't earning its keep.
    """
    log = PipelineLogger.get()
    log.step("PLAN-FAST", context.phase_id,
             f"templated planning for {context.script_name}",
             prompt_snippet=context.plan_prompt[:200])

    prompt = f"""# Mission
{context.plan_prompt[:6000]}

# Repo root
{context.repo_root}

# Available input artifacts (use ONLY these exact filenames)
{', '.join(context.existing_artifacts) if context.existing_artifacts else '(none)'}

# Output dir
{context.repo_root}/Analysis/artifacts/

# Hard requirements
- Minimum sample size: n >= {context.min_sample_size}. Define `MIN_N = {context.min_sample_size}` near the top. Flag findings on n<MIN_N as INSUFFICIENT.
- Defensive: handle empty DataFrames, missing columns, division by zero.
- Reproducibility: np.random.seed(42) wherever randomness appears.
- Output: print() with [INPUT], [CHECK], [RESULT], [SAVED] tags. These are RUNTIME prints, NOT bare lines in the source.
- All paths via pathlib.Path.
- The first line of your output must be valid Python (import / # comment / etc).
"""

    result = GeminiScriptRequest(
        prompt=prompt,
        phase_id=context.phase_id,
        script_name=context.script_name,
    )
    log.step_done("PLAN-FAST", context.phase_id,
                  f"templated prompt ready ({len(result.prompt)} chars)")
    return result


# ---------------------------------------------------------------------------
# Local script validation gate (runs before Claude review)
# ---------------------------------------------------------------------------

@activity.defn
async def validate_generated_script(
    script_content: str,
    available_artifacts: List[str],
    min_sample_size: int = 30,
) -> ValidationResult:
    """
    Pre-Claude-review validation. Catches predictable failures cheaply:
    syntax errors, missing print sections, missing min_n enforcement,
    references to nonexistent artifacts, etc.

    If this returns passed=False, the workflow hands the issues back
    to the writer as feedback — Claude review is skipped for that
    iteration (no point burning a review call on broken code).
    """
    return validate_script(
        script=script_content,
        available_artifacts=available_artifacts,
        min_sample_size=min_sample_size,
    )


# ---------------------------------------------------------------------------
# GEMINI — Write the Python script
# ---------------------------------------------------------------------------

@activity.defn
async def gemini_write_ml_script(
    request: GeminiScriptRequest,
    feedback: Optional[str],
) -> str:
    log = PipelineLogger.get()
    log.step("WRITE", request.phase_id,
             f"Gemini writing {request.script_name}"
             + (" (with feedback)" if feedback else ""),
             prompt_snippet=request.prompt[:200])
    feedback_block = ""
    if feedback:
        feedback_block = f"""
IMPORTANT — Your previous script was rejected:
{feedback}
Fix all issues listed above.
"""

    prompt = f"""{request.prompt}

{feedback_block}

CRITICAL RULES:
- Write ONE complete Python script. No placeholders, no TODOs, no `pass` in live paths.
- Libraries: pandas, numpy, pyarrow, scipy, sklearn, optuna as needed.
- All paths use pathlib.Path.
- Script must be self-contained and runnable.
- Print [INPUT], [PARSE], [CHECK], [RESULT], [SAVED] sections.
- Print [DISCOVERY], [ANOMALY], [INSIGHT] when findings warrant.
- np.random.seed(42) wherever randomness appears.
- Save outputs to Analysis/artifacts/.
- Handle empty DataFrames, missing columns, division by zero defensively.
- Flag findings with n < minimum sample size as INSUFFICIENT; do not report them.

Return the COMPLETE Python script content. No markdown fences, no explanation
outside the script. Just the raw .py file content.
"""
    try:
        result = await _gemini("COMPILER").prompt(prompt)
    except Exception:
        log.warning(request.phase_id, "Primary Gemini failed, using fallback")
        result = await _gemini("FALLBACK").prompt(prompt)
    log.step_done("WRITE", request.phase_id,
                  f"Script written ({len(result)} chars, {result.count(chr(10))} lines)",
                  response_snippet=result[:300])
    return result


# ---------------------------------------------------------------------------
# CLAUDE — Review the script (full length, not 8k-truncated)
# ---------------------------------------------------------------------------

@activity.defn
async def claude_review_ml_script(
    request: GeminiScriptRequest,
    script_content: str,
) -> ScriptReviewDecision:
    log = PipelineLogger.get()
    log.step("REVIEW", request.phase_id,
             f"[{get_runner('reviewer').provider_name}] reviewing "
             f"{request.script_name} ({len(script_content)} chars)")
    runner = get_runner("reviewer")

    # Stage 1: raise review budget from 8k to 20k. Long analysis scripts
    # have their save-logic and main block at the bottom — don't cut it.
    max_script_chars = 20_000
    if len(script_content) > max_script_chars:
        # Keep head and tail — skip middle
        head = script_content[: max_script_chars // 2]
        tail = script_content[-(max_script_chars // 2):]
        script_view = f"{head}\n\n# ... ({len(script_content) - max_script_chars} chars elided from middle) ...\n\n{tail}"
    else:
        script_view = script_content

    prompt = f"""You are a senior quantitative researcher reviewing a Python analysis script
BEFORE it runs. You catch both bugs AND analytical weaknesses.

Phase {request.phase_id} ({request.script_name})

WHAT IT SHOULD ACCOMPLISH:
{request.prompt[:3500]}

SCRIPT:
```python
{script_view}
```

REVIEW ON TWO AXES:

A. CORRECTNESS (hard reject if any fail):
   1. Reads correct input files from Analysis/artifacts/
   2. Saves outputs to Analysis/artifacts/
   3. No syntax errors, undefined vars, missing imports
   4. No Windows-broken paths
   5. No placeholder/TODO/pass in live code paths
   6. Prints required sections: [INPUT] [CHECK] [RESULT] [SAVED]
   7. Handles empty DataFrames, missing columns, division by zero
   8. Respects the minimum sample size requirement (flags n<threshold findings)

B. ANALYTICAL DEPTH (flag as "DEPTH:" in risk_flags, don't hard-reject):
   1. Computes CIs, not just point estimates
   2. Tests statistical significance (not just descriptives)
   3. Checks distributions before parametric assumptions
   4. Regime / session splits where relevant
   5. Cross-correlations between related variables
   6. Addresses known pathologies from accumulated insights

Reject if: incomplete code, will crash, reads wrong files, has TODOs, ignores min n.
Approve with flags if: code will run correctly and depth is at least minimal.

Return JSON:
- approved (bool)
- verdict (one sentence covering both axes)
- risk_flags (list — depth concerns prefixed with "DEPTH:")
- notes (concrete suggestion for highest-impact improvement)
"""
    result = await runner.prompt_json(prompt, ScriptReviewDecision)
    status = "APPROVED" if result.approved else "REJECTED"
    log.step_done("REVIEW", request.phase_id,
                  f"{status}: {result.verdict}",
                  extra={"approved": result.approved,
                         "risk_flags": result.risk_flags})
    if not result.approved:
        log.warning(request.phase_id,
                    f"Review rejected: {result.notes}")
    return result


# ---------------------------------------------------------------------------
# Save and run the script
# ---------------------------------------------------------------------------

@activity.defn
async def save_and_run_ml_script(
    script_name: str,
    script_content: str,
    repo_root: str,
) -> ScriptRunResult:
    log = PipelineLogger.get()
    log.step("RUN", script_name, f"Saving and executing {script_name}")
    scripts_dir = Path(repo_root) / "Analysis" / "scripts"
    scripts_dir.mkdir(parents=True, exist_ok=True)
    script_path = scripts_dir / script_name

    # Strip markdown fences if Gemini wrapped the code
    content = script_content.strip()
    if content.startswith("```"):
        first_newline = content.index("\n")
        content = content[first_newline + 1:]
    if content.endswith("```"):
        content = content[:-3].rstrip()

    script_path.write_text(content, encoding="utf-8")

    venv_python = Path(repo_root) / "venv" / "Scripts" / "python.exe"
    if not venv_python.exists():
        venv_python = Path(repo_root) / "venv" / "bin" / "python"
    if not venv_python.exists():
        venv_python = "python"

    try:
        result = subprocess.run(
            [str(venv_python), str(script_path)],
            cwd=repo_root,
            capture_output=True,
            text=True,
            timeout=600,
        )

        artifacts_dir = Path(repo_root) / "Analysis" / "artifacts"
        artifacts = []
        if artifacts_dir.exists():
            for f in artifacts_dir.iterdir():
                if f.suffix in {".parquet", ".csv", ".md", ".json"}:
                    artifacts.append(f.name)

        stdout = result.stdout
        if len(stdout) > 5000:
            stdout = stdout[:2000] + "\n...(truncated)...\n" + stdout[-2000:]
        stderr = result.stderr
        if len(stderr) > 3000:
            stderr = stderr[:1500] + "\n...(truncated)...\n" + stderr[-1500:]

        run_result = ScriptRunResult(
            success=result.returncode == 0,
            script_path=str(script_path),
            stdout=stdout,
            stderr=stderr,
            artifacts_produced=sorted(artifacts),
        )
        status = "SUCCESS" if run_result.success else "FAILED"
        log.step_done("RUN", script_name,
                      f"{status} — {len(run_result.artifacts_produced)} artifacts",
                      response_snippet=stdout[:300],
                      extra={"returncode": result.returncode,
                             "artifacts": run_result.artifacts_produced})
        if not run_result.success:
            log.error(script_name, f"Script failed: {stderr[:300]}")
        return run_result
    except subprocess.TimeoutExpired:
        log.error(script_name, "Script timed out after 600 seconds")
        return ScriptRunResult(
            success=False,
            script_path=str(script_path),
            stdout="",
            stderr="Script timed out after 600 seconds",
            artifacts_produced=[],
        )
    except Exception as e:
        log.error(script_name, f"Script crashed: {e}")
        return ScriptRunResult(
            success=False,
            script_path=str(script_path),
            stdout="",
            stderr=str(e),
            artifacts_produced=[],
        )


# ---------------------------------------------------------------------------
# CLAUDE — Evaluate output (now returns confidence + optional micro-phase)
# ---------------------------------------------------------------------------

@activity.defn
async def claude_evaluate_ml_output(
    phase_id: str,
    script_name: str,
    run_result: ScriptRunResult,
    expected_artifacts: str,
) -> PhaseEvaluation:
    log = PipelineLogger.get()
    log.step("EVALUATE", phase_id,
             f"[{get_runner('evaluator').provider_name}] evaluating {script_name} output"
             + (" (script failed)" if not run_result.success else ""))
    runner = get_runner("evaluator")

    prompt = f"""You are a senior quant evaluating Phase {phase_id} ({script_name}).
Go beyond pass/fail — mine the output for insights, spot anomalies, and assess
confidence.

Return code: {"SUCCESS" if run_result.success else "FAILED"}

STDOUT:
{run_result.stdout[:4000]}

STDERR:
{run_result.stderr[:1500]}

Artifacts produced: {', '.join(run_result.artifacts_produced)}

Expected: {expected_artifacts}

EVALUATE ON THREE LEVELS:

1. EXECUTION — clean exit? expected artifacts? data-quality warnings?

2. RESULTS — numbers in reasonable ranges? distributions make sense? sample
   sizes adequate? CIs tight or fragile? contradictions with prior phases?

3. INSIGHTS — top 3-5 findings with numbers and variables; anomalies needing
   follow-up; unplanned patterns; hypotheses for later phases.

CONFIDENCE ASSESSMENT (critical for later finalization gate):
- HIGH: clean execution, n ≥ 30 per cell, tight CIs, p < 0.05 on key findings,
  results stable across temporal splits
- MEDIUM: results plausible but some samples small, CIs wide, or stability
  uncertain
- LOW: execution succeeded but findings are likely noise (small n, wide CIs,
  no significance, or contradicts prior phases without explanation)

MICRO-PHASE PROPOSAL (use ONLY when an anomaly materially threatens later phases):
If the output reveals a fundamental issue — e.g. replay harness can't reproduce
backtest PnL within 5%, a key variable has unexpected distribution, or a prior
insight is contradicted — propose a targeted micro-phase via `proposed_micro_phase`.
Otherwise leave it null. Do NOT propose micro-phases for every finding.

Return JSON:
- passed (bool)
- issues (list of strings — empty if passed)
- artifacts_validated (list)
- summary (2-3 sentences: what was FOUND, not "ran successfully")
- next_action (CONTINUE | RETRY | STOP | INSERT_MICRO_PHASE)
- key_insights (list — specific findings with numbers, variables, directions)
- suggested_follow_ups (list — unplanned angles the data suggests)
- confidence_level (HIGH | MEDIUM | LOW)
- confidence_rationale (one sentence — justify the level)
- proposed_micro_phase (null OR object with phase_id, script_name, rationale,
  inline_prompt, dependencies, insert_before)
"""
    result = await runner.prompt_json(prompt, PhaseEvaluation)
    status = "PASSED" if result.passed else "FAILED"
    log.step_done("EVALUATE", phase_id,
                  f"{status} [{result.confidence_level.value}]: {result.summary[:150]}",
                  extra={"passed": result.passed,
                         "confidence": result.confidence_level.value,
                         "n_insights": len(result.key_insights),
                         "has_micro_phase": result.proposed_micro_phase is not None})
    for ins in result.key_insights:
        log.insight(phase_id, ins)
    if result.proposed_micro_phase:
        log.event("MICRO_PHASE_PROPOSED", phase_id=phase_id,
                  micro_id=result.proposed_micro_phase.phase_id,
                  rationale=result.proposed_micro_phase.rationale)
    return result


# ---------------------------------------------------------------------------
# CLAUDE — Confidence audit (gate before finalization)
# ---------------------------------------------------------------------------

@activity.defn
async def audit_phase_confidence(phase_results: List[PhaseResult]) -> ConfidenceAudit:
    """
    Deterministic audit: counts confidence levels. No Claude call needed —
    the assessment was made at each phase's evaluation.

    Gate policy (from role doc): passes when >= 3 HIGH confidence phases.
    """
    log = PipelineLogger.get()
    log.event("CONFIDENCE_AUDIT", total_phases=len(phase_results))
    high = [r for r in phase_results if r.confidence_level == ConfidenceLevel.HIGH]
    medium = [r for r in phase_results if r.confidence_level == ConfidenceLevel.MEDIUM]
    low = [r for r in phase_results if r.confidence_level == ConfidenceLevel.LOW]

    concerning = [f"{r.phase_id} ({r.confidence_rationale[:80]})" for r in low]

    passes = len(high) >= 3
    if passes:
        rationale = (
            f"{len(high)} HIGH-confidence phases meet the finalization bar. "
            f"Proposal can be issued with HIGH confidence."
        )
    else:
        rationale = (
            f"Only {len(high)} HIGH-confidence phases (need ≥3). "
            f"Proposal must be marked LOW_CONFIDENCE; recommend additional "
            f"data collection before deployment."
        )

    audit = ConfidenceAudit(
        total_phases_evaluated=len(phase_results),
        high_confidence_count=len(high),
        medium_confidence_count=len(medium),
        low_confidence_count=len(low),
        passes_finalization_gate=passes,
        rationale=rationale,
        concerning_phases=concerning,
    )
    gate_status = "PASSED" if passes else "FAILED"
    log.event("CONFIDENCE_RESULT",
              gate=gate_status,
              high=len(high), medium=len(medium), low=len(low),
              rationale=rationale)
    return audit


# ---------------------------------------------------------------------------
# CLAUDE — Build the final ML proposal (Phase 17)
# ---------------------------------------------------------------------------

@activity.defn
async def build_ml_proposal(
    phase_results: List[PhaseResult],
    confidence_audit: ConfidenceAudit,
    proposal_version: str,
) -> MLProposal:
    """
    Claude synthesizes all phase findings into a structured MLProposal.
    Each change must trace to a specific phase — no unsourced claims.
    """
    log = PipelineLogger.get()
    log.step("PROPOSAL", "finalize",
             f"[{get_runner('proposal_builder').provider_name}] building proposal "
             f"v{proposal_version} from {len(phase_results)} phases")
    runner = get_runner("proposal_builder")

    # Build a compact briefing of all phase results
    briefing_lines = []
    for r in phase_results:
        briefing_lines.append(
            f"## Phase {r.phase_id} — {r.status.value} — {r.confidence_level.value}\n"
            f"Summary: {r.evaluation_summary}\n"
            f"Insights:\n" + "\n".join(f"  - {i}" for i in r.key_insights) + "\n"
        )
    briefing = "\n".join(briefing_lines)

    gate_note = (
        f"Confidence audit: {confidence_audit.high_confidence_count} HIGH, "
        f"{confidence_audit.medium_confidence_count} MEDIUM, "
        f"{confidence_audit.low_confidence_count} LOW. "
        f"Gate {'PASSED' if confidence_audit.passes_finalization_gate else 'FAILED'}. "
        f"{confidence_audit.rationale}"
    )

    prompt = f"""You are the senior quant finalizing a config proposal for deployment.
Synthesize all phase findings into a structured proposal.

{gate_note}

PHASE RESULTS:
{briefing[:10000]}

RULES:
- Every weight_change, veto_change, and threshold_change MUST cite the specific
  phase and finding that justifies it. Unsourced changes are not allowed.
- If the confidence gate FAILED, set confidence_level to LOW and explain in
  confidence_rationale. Be honest — don't inflate confidence to satisfy the
  structure.
- expected_improvement.confidence_interval must come from a bootstrap or
  Monte Carlo phase (typically Phase 14). If no such phase exists, set the
  interval to [pnl_estimate * 0.5, pnl_estimate * 1.5] and note this as
  'ESTIMATE ONLY — no bootstrap basis' in the basis field.
- bugs_to_fix should come from the bug-hunt branch (Phases 25-28).
- risks must list at least 3 items — overfitting, regime dependency, small-n
  findings, correlated changes, etc.

Proposal version: {proposal_version}

Return JSON matching the MLProposal schema:
- proposal_version (string)
- confidence_level (HIGH | MEDIUM | LOW)
- confidence_rationale (sentence)
- weight_changes (list of {{source_name, old_value, new_value, basis}})
- veto_changes (list of {{signal_name, action, basis}})
- threshold_changes (list of {{parameter, old_value, new_value, basis}})
- trade_management_changes (dict of parameter -> new_value, with "_basis" keys)
- bugs_to_fix (list of {{id, severity, description, phase_source}})
- expected_improvement (object: pnl_delta_estimate, win_rate_delta,
  confidence_interval: [lo, hi], basis)
- risks (list of strings)
- recommended_next_backtest (dict)
"""
    result = await runner.prompt_json(prompt, MLProposal)
    log.step_done("PROPOSAL", "finalize",
                  f"Proposal built: {result.confidence_level.value} confidence, "
                  f"{len(result.weight_changes)} weight changes, "
                  f"{len(result.bugs_to_fix)} bugs",
                  extra={"confidence": result.confidence_level.value,
                         "weight_changes": len(result.weight_changes),
                         "veto_changes": len(result.veto_changes),
                         "threshold_changes": len(result.threshold_changes),
                         "bugs": len(result.bugs_to_fix)})
    return result


# ---------------------------------------------------------------------------
# Deterministic write of the proposal JSON to disk
# ---------------------------------------------------------------------------

@activity.defn
async def write_proposal_to_disk(proposal: MLProposal, output_path: str) -> str:
    p = Path(output_path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(proposal.model_dump_json(indent=2), encoding="utf-8")
    return str(p)
